package kawa.lang;
/* loaded from: classes.dex */
public class GenericError extends RuntimeException {
    public GenericError(String message) {
        super(message);
    }
}
