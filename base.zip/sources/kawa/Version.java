package kawa;
/* loaded from: classes.dex */
public class Version {
    public static String getVersion() {
        return "1.11";
    }
}
