package kawa.standard;

import gnu.expr.Declaration;
import gnu.expr.LetExp;
/* compiled from: syntax_case.java */
/* loaded from: classes.dex */
class syntax_case_work {
    Declaration inputExpression;
    LetExp let;
    Object[] literal_identifiers;
    int maxVars;
}
