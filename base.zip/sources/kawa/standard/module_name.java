package kawa.standard;

import kawa.lang.Syntax;
/* loaded from: classes.dex */
public class module_name extends Syntax {
    public static final module_name module_name = new module_name();

    static {
        module_name.setName("module-name");
    }

    /* JADX WARN: Removed duplicated region for block: B:26:0x005a  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x00b1  */
    @Override // kawa.lang.Syntax
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void scanForm(gnu.lists.Pair r18, gnu.expr.ScopeExp r19, kawa.lang.Translator r20) {
        /*
            Method dump skipped, instructions count: 368
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: kawa.standard.module_name.scanForm(gnu.lists.Pair, gnu.expr.ScopeExp, kawa.lang.Translator):void");
    }
}
