package com.google.appinventor.components.common;
/* renamed from: com.google.appinventor.components.common.package-info  reason: invalid class name */
/* loaded from: classes.dex */
interface packageinfo {
}
