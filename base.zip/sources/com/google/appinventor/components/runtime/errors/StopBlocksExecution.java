package com.google.appinventor.components.runtime.errors;
/* loaded from: classes.dex */
public final class StopBlocksExecution extends RuntimeException {
}
