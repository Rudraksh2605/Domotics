package com.google.appinventor.components.runtime.errors;
/* renamed from: com.google.appinventor.components.runtime.errors.package-info  reason: invalid class name */
/* loaded from: classes.dex */
interface packageinfo {
}
