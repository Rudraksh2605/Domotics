package com.google.appinventor.components.runtime;

import android.content.Intent;
/* loaded from: classes.dex */
public interface ActivityResultListener {
    void resultReturned(int i, int i2, Intent intent);
}
