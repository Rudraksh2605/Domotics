package com.google.appinventor.components.runtime;

import android.view.MenuItem;
/* loaded from: classes.dex */
public interface OnOptionsItemSelectedListener {
    boolean onOptionsItemSelected(MenuItem menuItem);
}
