package com.google.appinventor.components.runtime.util;
/* loaded from: classes.dex */
public interface Continuation<T> {
    void call(T t);
}
