package com.google.appinventor.components.runtime.util;
/* loaded from: classes.dex */
public interface OnInitializeListener {
    void onInitialize();
}
