package com.google.appinventor.components.runtime.util;

import android.os.Build;
import android.os.Environment;
import com.google.appinventor.components.common.FileScope;
import com.google.appinventor.components.runtime.Form;
/* loaded from: classes.dex */
public class RUtil {
    public static boolean needsFilePermission(Form form, String path, FileScope fileScope) {
        if (fileScope != null) {
            switch (fileScope) {
                case App:
                    return Build.VERSION.SDK_INT < 19;
                case Asset:
                    return form.isRepl() && Build.VERSION.SDK_INT < 19;
                case Shared:
                    return true;
                default:
                    return false;
            }
        } else if (path.startsWith("//")) {
            return false;
        } else {
            if (!path.startsWith("/") && !path.startsWith("file:")) {
                return false;
            }
            if (path.startsWith("file:")) {
                path = path.substring(5);
            }
            if (Build.VERSION.SDK_INT < 8) {
                return path.startsWith(Environment.getExternalStorageDirectory().getAbsolutePath());
            }
            String path2 = "file:" + path;
            return FileUtil.isExternalStorageUri(form, path2) && !FileUtil.isAppSpecificExternalUri(form, path2);
        }
    }
}
