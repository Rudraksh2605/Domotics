package com.google.appinventor.common.version;
/* renamed from: com.google.appinventor.common.version.package-info  reason: invalid class name */
/* loaded from: classes.dex */
interface packageinfo {
}
