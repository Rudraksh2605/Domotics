package com.google.appinventor.common.version;
/* loaded from: classes.dex */
public final class GitBuildId {
    public static final String ACRA_URI = "${acra.uri}";
    public static final String ANT_BUILD_DATE = "December 8 2021";
    public static final String GIT_BUILD_FINGERPRINT = "60c4208946fd44ee44f1becc70109f0e7857e3ec";
    public static final String GIT_BUILD_VERSION = "nb188a";

    private GitBuildId() {
    }

    public static String getVersion() {
        if (GIT_BUILD_VERSION != "" && !GIT_BUILD_VERSION.contains(" ")) {
            return GIT_BUILD_VERSION;
        }
        return "none";
    }

    public static String getFingerprint() {
        return GIT_BUILD_FINGERPRINT;
    }

    public static String getDate() {
        return ANT_BUILD_DATE;
    }

    public static String getAcraUri() {
        return ACRA_URI.equals(ACRA_URI) ? "" : ACRA_URI.trim();
    }
}
